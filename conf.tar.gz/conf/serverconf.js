module.exports = {
	"token" : "0e31585320d29e3db8ca8cbeab99ed5f0D7BE7ABF62C6B2B116939425C9D0537945796ED",
	"secretWord" : "mysecretword",
	"source"     : "15766062",
	"mailPass"   : "P@$$w0rd123",
	"mailUser"   : "schooltrackingsystems@gmail.com",
	"cycle"			 : "dev"
}
